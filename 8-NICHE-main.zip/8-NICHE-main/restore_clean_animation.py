import re

file_path = 'index.html'

with open(file_path, 'r', encoding='utf-8') as f:
    content = f.read()

# 1. Clean up old animation blocks just in case
content = re.sub(r'<style id="bg-animation">.*?</style>', '', content, flags=re.DOTALL)

# 2. Inject Refined Animation
refined_animation_css = """
<style id="bg-animation">
    /* Refined Animation: No Borders */
    @keyframes bg-toggle {
        0%, 45% {
            background-color: #fff;
            background-image:
              linear-gradient(45deg, #ccc 25%, transparent 25%),
              linear-gradient(-45deg, #ccc 25%, transparent 25%),
              linear-gradient(45deg, transparent 75%, #ccc 75%),
              linear-gradient(-45deg, transparent 75%, #ccc 75%);
            background-size: 20px 20px;
        }
        50%, 95% {
            background-color: #000;
            background-image: none;
        }
        100% {
            background-color: #fff;
            background-image:
              linear-gradient(45deg, #ccc 25%, transparent 25%),
              linear-gradient(-45deg, #ccc 25%, transparent 25%),
              linear-gradient(45deg, transparent 75%, #ccc 75%),
              linear-gradient(-45deg, transparent 75%, #ccc 75%);
            background-size: 20px 20px;
        }
    }

    .dc, .v-card {
        animation: bg-toggle 20s linear infinite;
        border: none !important; /* Force no border at all times */
        box-shadow: none !important; /* Ensure no shadow either */
    }
</style>
"""

if '</body>' in content:
    content = content.replace('</body>', refined_animation_css + '</body>')
else:
    content += refined_animation_css

with open(file_path, 'w', encoding='utf-8') as f:
    f.write(content)

print("Refined Animation Applied.")
