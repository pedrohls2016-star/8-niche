import re

file_path = 'index.html'

with open(file_path, 'r', encoding='utf-8') as f:
    content = f.read()

# 1. REMOVE PREVIOUS FAILED ANIMATION BLOCKS
# Remove <style id="bg-animation">...</style>
content = re.sub(r'<style id="bg-animation">.*?</style>', '', content, flags=re.DOTALL)

# 2. REMOVE !important FROM STATIC BACKGROUNDS
# We need to find the specific block or lines. 
# The lines are like: `background-color: #fff !important;` inside `.dc, .v-card` or `.dc` blocks.
# Since my previous script `fix_shadows_and_size.py` also added styles with !important.
# Let's replace `background-.*!important` with `background-.*;` GLOBALLY for `.dc` and `.v-card` contexts?
# That's hard with regex on the full file.

# Target specific strings I injected.
# From apply_light_theme.py:
# .dc, .v-card {
#    background-color: #fff !important;
#    background-image: ... !important;
# }
# Replaces:
content = content.replace('background-color: #fff !important;', 'background-color: #fff;')
content = content.replace('background-color: #FFFFFF !important;', 'background-color: #FFFFFF;')

# Also the gradients
# This string is long/complex. 
# Let's simple remove `!important` from ANY `background-image` line that contains `linear-gradient`.
# This might affect other things, but most other things are okay to lose !important if we want animation.
# But better: Target the Checkerboard pattern specifically.
checkerboard_pattern = r'(linear-gradient\(45deg, #ccc 25%, transparent 25%\).*?)\s*!important'
content = re.sub(checkerboard_pattern, r'\1', content, flags=re.DOTALL)

# 3. INJECT CORRECT ANIMATION (No !important in keyframes)
final_animation_css = """
<style id="bg-animation">
    /* Animation Keyframes */
    @keyframes bg-toggle {
        0%, 45% {
            background-color: #fff;
            background-image:
              linear-gradient(45deg, #ccc 25%, transparent 25%),
              linear-gradient(-45deg, #ccc 25%, transparent 25%),
              linear-gradient(45deg, transparent 75%, #ccc 75%),
              linear-gradient(-45deg, transparent 75%, #ccc 75%);
            background-size: 20px 20px;
            border-color: #ddd;
        }
        50%, 95% {
            background-color: #000;
            background-image: none;
            border-color: #333;
        }
        100% {
            background-color: #fff;
            background-image:
              linear-gradient(45deg, #ccc 25%, transparent 25%),
              linear-gradient(-45deg, #ccc 25%, transparent 25%),
              linear-gradient(45deg, transparent 75%, #ccc 75%),
              linear-gradient(-45deg, transparent 75%, #ccc 75%);
            background-size: 20px 20px;
            border-color: #ddd;
        }
    }

    /* Apply to elements */
    .dc, .v-card {
        animation: bg-toggle 20s linear infinite;
        /* Ensure basic styles don't block it. 
           We already removed !important above. 
           We add `background-image: none` to the base class just in case? 
           No, let the keyframe 0% handle it. */
    }
</style>
"""

if '</body>' in content:
    content = content.replace('</body>', final_animation_css + '</body>')
else:
    content += final_animation_css

with open(file_path, 'w', encoding='utf-8') as f:
    f.write(content)

print("Animation Fixed and Re-applied.")
