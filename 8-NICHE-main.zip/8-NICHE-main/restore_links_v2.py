file_path = 'index.html'

with open(file_path, 'r', encoding='utf-8') as f:
    content = f.read()

# Target string exactly as it appears in the file
# src="'+("images/"+n.split("/").pop())+'"
target_str = """src="'+("images/"+n.split("/").pop())+'" """
# Note: The space at the end of triple quote might control newline, but here I want the content.
# Let's use single quotes with escaping to be precise.
target_str = 'src="\'+("images/"+n.split("/").pop())+\'"'

# We want to replace it with: src="https://i.ibb.co/'+n+'"
replacement_str = 'src="https://i.ibb.co/\'+n+\'"'

# Perform replacement
new_content = content.replace(target_str, replacement_str)

if new_content == content:
    print("WARNING: String match failed for main gallery loader.")
    # Debugging: Print a snippet from content to see what we are missing
    # Searching for 'src="'+("images/"'
    snippet_idx = content.find('src="\'+("images/"')
    if snippet_idx != -1:
        print(f"Found snippet at {snippet_idx}: {content[snippet_idx:snippet_idx+50]}")
    else:
        print("Could not find the target string even partially.")

# Try a looser replacement just in case of whitespace differences
# src="'+("images/" + n.split("/").pop())+'"
# vs src="'+("images/"+n.split("/").pop())+'"
# We can use regex.
import re
# Regex to match: src="'\+\("images/"\+n\.split\("/"\)\.pop\(\)\)\+'"
# We need to escape special regex chars: + ( )
regex_pattern = r'src="\'\+\("images/"\+n\.split\("/"\)\.pop\(\)\)\+\'"'

new_content = re.sub(regex_pattern, 'src="https://i.ibb.co/\'+n+\'"', content)

if new_content != content:
    print("Regex replacement success.")
else:
    print("Regex replacement failed.")


# Vault/Carousel loader
# Likely same pattern
# Check for other "images/" usages in JS
# Found in file: src="images/wwwcsacawwwwwwwwwwwwwwwwwwwwwwwwwwww.gif"
# This is a static image. I don't have the link. 
# But the user said "voce baixou", so I might have downloaded it.
# Check if I can find a URL for "wwwcsacawwwwwwwwwwwwwwwwwwwwwwwwwwww.gif" in the file history?
# Assuming I can't easily, I will leave it for now or ask user if broken.
# But I WILL fix the bulk galleries.

with open(file_path, 'w', encoding='utf-8') as f:
    f.write(new_content)

print("Restoration script completed.")
