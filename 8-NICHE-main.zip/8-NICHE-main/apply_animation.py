import re

file_path = 'index.html'

with open(file_path, 'r', encoding='utf-8') as f:
    content = f.read()

# 1. Remove !important from previous background definitions used in apply_light_theme.py and fix_shadows_and_size.py
# If they exist in the file.
# The problematic part is:
# .dc { background-color: #fff !important; ... }
# .v-card { ... background-color: #fff !important; ... }
# We need to remove the "!important" from these specific lines related to background to let animation take over.

# Instead of regex replacement which might be risky, let's just append the animation with !important in the keyframes?
# Actually, keyframe !important IS supported in modern browsers to override !important styles on the element.
# Let's try that first as it's cleaner than modifying earlier code blocks.

animation_css = """
<style id="bg-animation">
    @keyframes bg-toggle {
        0%, 45% {
            background-color: #fff !important;
            background-image:
              linear-gradient(45deg, #ccc 25%, transparent 25%),
              linear-gradient(-45deg, #ccc 25%, transparent 25%),
              linear-gradient(45deg, transparent 75%, #ccc 75%),
              linear-gradient(-45deg, transparent 75%, #ccc 75%) !important;
            background-size: 20px 20px !important;
            background-position: 0 0, 0 10px, 10px -10px, -10px 0px !important;
            border: 1px solid #ddd !important;
        }
        50%, 95% {
            background-color: #000 !important;
            background-image: none !important;
            border: 1px solid #333 !important;
        }
        100% {
            background-color: #fff !important;
            background-image:
              linear-gradient(45deg, #ccc 25%, transparent 25%),
              linear-gradient(-45deg, #ccc 25%, transparent 25%),
              linear-gradient(45deg, transparent 75%, #ccc 75%),
              linear-gradient(-45deg, transparent 75%, #ccc 75%) !important;
            background-size: 20px 20px !important;
            background-position: 0 0, 0 10px, 10px -10px, -10px 0px !important;
             border: 1px solid #ddd !important;
        }
    }

    .dc, .v-card {
        animation: bg-toggle 20s linear infinite !important;
        transition: background-color 0.5s ease; /* For smoothness if possible */
    }
</style>
"""

# Append to head
if '</head>' in content:
    content = content.replace('</head>', animation_css + '\n</head>')
else:
    content += animation_css

with open(file_path, 'w', encoding='utf-8') as f:
    f.write(content)

print("Background Animation Applied.")
