file_path = 'index.html'

polish_css = """
<style id="hero-polish">
    /* --- HERO POLISH (OVERRIDES) --- */
    
    /* 1. Typography & Headline */
    body section h1.color-FFFFFF {
        font-family: 'Sora', sans-serif !important; /* Ensure premium font */
        letter-spacing: -1.5px !important; /* Tighter for modern look */
        line-height: 1.2 !important;
        font-size: 30px !important; /* Slightly larger */
        background: linear-gradient(180deg, #000000 0%, #222222 100%);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        margin-bottom: 30px !important;
    }
    
    /* 2. Gold Glow */
    body section h1 .color-FFD700 {
        -webkit-text-fill-color: initial !important; /* Reset clip for gold text if needed, or keep gradient */
        background: linear-gradient(135deg, #FFD700 0%, #FDB931 100%);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        filter: drop-shadow(0 0 10px rgba(255, 215, 0, 0.3)); /* Glow */
    }

    /* 3. Alert Box Refinement */
    .hero-alert-box {
        background: radial-gradient(circle at top, #FAFAFA, #F5F5F5) !important;
        border: 1px solid #E5E5E5 !important;
        box-shadow: 
            0 10px 15px -3px rgba(0, 0, 0, 0.03), 
            0 4px 6px -2px rgba(0, 0, 0, 0.02),
            inset 0 1px 0 rgba(255,255,255, 0.8) !important; /* Inner highlight */
        border-radius: 16px !important;
        padding: 25px 20px !important;
        position: relative;
        overflow: hidden;
    }
    
    /* Subtle Gold Accent Line on Top */
    .hero-alert-box::before {
        content: '';
        position: absolute;
        top: 0; left: 0; right: 0;
        height: 2px;
        background: linear-gradient(90deg, transparent, rgba(212, 175, 55, 0.3), transparent);
    }
    
    .hero-alert-box p {
        color: #444 !important;
        font-size: 15px !important;
        font-weight: 500 !important;
    }

    /* 4. Button / Badge Upgrade */
    span.money-badge {
        background: #050505 !important;
        padding: 14px 28px !important;
        font-size: 15px !important;
        letter-spacing: 1px !important;
        border: 1px solid rgba(255, 215, 0, 0.2) !important;
        box-shadow: 
            0 10px 20px -5px rgba(0, 0, 0, 0.4),
            0 0 15px rgba(255, 215, 0, 0.1) !important;
        transition: transform 0.2s ease, box-shadow 0.2s ease;
    }
    
    /* Hover Effect (Simulated in specific conditions only, but good to have) */
    span.money-badge:hover {
        transform: translateY(-2px);
        box-shadow: 0 15px 30px -5px rgba(0,0,0,0.5), 0 0 20px rgba(255,215,0,0.2) !important;
    }
    
    /* "Stop digging" emphasis */
    .hero-alert-box p span.color-FFFFFF, 
    .hero-alert-box p span[style*="color:#111"] {
        margin-top: 15px !important;
        display: block !important;
    }

</style>
"""

with open(file_path, 'r', encoding='utf-8') as f:
    content = f.read()

# Append to end of body
if '</body>' in content:
    content = content.replace('</body>', polish_css + '</body>')
else:
    content += polish_css

with open(file_path, 'w', encoding='utf-8') as f:
    f.write(content)

print("Hero Polished.")
