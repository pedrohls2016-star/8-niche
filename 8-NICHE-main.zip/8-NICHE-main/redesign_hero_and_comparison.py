import re

file_path = 'index.html'

with open(file_path, 'r', encoding='utf-8') as f:
    content = f.read()

# --- 1. CSS INJECTION ---
redesign_css = """
<style id="premium-redesign">
    /* --- HERO SECTION REDESIGN --- */
    /* Target the specific hero section container */
    /* It has classes: bg-0F0F0F color-F5F5F5 ... max-width:480px ... box-shadow ... */
    /* We match it via specificity on body */
    
    body section.bg-0F0F0F[style*="max-width:480px"][style*="box-shadow"] {
        background: #FFFFFF !important;
        border: 1px solid #EAEAEA !important;
        box-shadow: 0 15px 50px rgba(0,0,0,0.06) !important;
        border-radius: 20px !important;
        padding-top: 40px !important;
        padding-bottom: 40px !important;
    }

    /* Hide the top "shimmer" bar in Hero if it looks weird on white */
    body section.bg-0F0F0F[style*="max-width:480px"] .bg-FFD700[style*="height:4px"] {
        opacity: 1 !important;
        background: #FFD700 !important; /* Keep gold accent */
    }

    /* Hero Headline */
    body section h1.color-FFFFFF {
        color: #111 !important;
        font-family: 'Sora', 'Inter', sans-serif !important;
        font-weight: 800 !important;
        font-size: 26px !important;
        line-height: 1.3 !important;
        letter-spacing: -0.5px !important;
        text-shadow: none !important;
        margin-bottom: 25px !important;
    }
    
    /* Highlight Spans in Headline */
    body section h1 .color-FFD700 {
        color: #B8860B !important; /* Darker Gold for visibility on white */
        background: linear-gradient(120deg, #B8860B, #DAA520);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        font-weight: 900 !important;
    }

    /* Subtitle "Curated..." */
    body section p.color-A0A0A0 {
        color: #666 !important;
        font-weight: 600 !important;
        font-size: 14px !important;
    }

    /* "Problem" Box wrapper (we will inject this class in HTML below) */
    .hero-alert-box {
        background: #F9F9F9 !important;
        border: 1px solid #EEE !important;
        border-radius: 12px !important;
        padding: 20px !important;
        margin-top: 25px !important;
        text-align: center !important;
    }
    
    .hero-alert-box p {
        color: #555 !important;
        font-size: 14px !important;
        line-height: 1.6 !important;
        margin-bottom: 15px !important;
    }

    /* "PUT MONEY IN YOUR POCKET" Badge */
    span.money-badge {
        display: inline-block !important;
        background: #000 !important;
        color: #FFD700 !important;
        font-weight: 800 !important;
        font-size: 14px !important;
        padding: 10px 20px !important;
        border-radius: 100px !important;
        letter-spacing: 0.5px !important;
        box-shadow: 0 4px 15px rgba(0,0,0,0.2) !important;
        animation: pulse-badge 2s infinite !important;
        margin-top: 10px !important;
    }
    
    @keyframes pulse-badge {
        0% { transform: scale(1); box-shadow: 0 0 0 0 rgba(0,0,0,0.2); }
        70% { transform: scale(1.05); box-shadow: 0 0 0 10px rgba(0,0,0,0); }
        100% { transform: scale(1); box-shadow: 0 0 0 0 rgba(0,0,0,0); }
    }

    /* --- COMPARISON TABLE REDESIGN --- */
    
    /* Container (The Difference) */
    section .comp-box {
        background: #FFF !important;
        border: 1px solid #EAEAEA !important;
        border-radius: 16px !important;
        box-shadow: 0 10px 30px rgba(0,0,0,0.05) !important;
        overflow: hidden !important;
    }

    /* Rows */
    section .comp-row {
        border-bottom: 1px solid #F0F0F0 !important;
    }
    section .comp-row:last-child {
        border-bottom: none !important;
    }

    /* Remove old black background on first row */
    section .comp-row.bg-000 {
        background: transparent !important;
    }

    /* Left Column (Bad) */
    section .col-bad {
        background: #F9F9F9 !important;
        border-right: 1px solid #EEE !important;
        color: #666 !important;
    }
    
    /* Right Column (Good) */
    section .col-good {
        background: #FFF !important;
        color: #222 !important;
    }
    
    /* Header Row Special Styling */
    section .comp-row:first-child .col-bad {
        background: #F0F0F0 !important;
        border-bottom: 2px solid #E0E0E0 !important;
        padding-top: 20px !important;
        padding-bottom: 20px !important;
    }
    section .comp-row:first-child .col-good {
        background: #FFF !important;
        border-bottom: 2px solid #FFD700 !important;
        padding-top: 20px !important;
        padding-bottom: 20px !important;
    }

    /* Typography in Table */
    section .bad-tit {
        color: #888 !important;
        font-weight: 700 !important;
        font-size: 11px !important;
        letter-spacing: 1px !important;
    }
    section .good-tit {
        color: #000 !important;
        font-weight: 900 !important;
        font-size: 12px !important;
        letter-spacing: 1px !important;
        text-shadow: none !important;
    }

    section .bad-txt {
        color: #777 !important;
        font-weight: 500 !important;
    }
    section .good-txt {
        color: #111 !important;
        font-weight: 700 !important;
        font-size: 13px !important;
    }
    
    /* Icons */
    section .icon-x { color: #E57373 !important; opacity: 0.8 !important; }
    section .icon-chk { color: #FFB300 !important; font-size: 16px !important; }

</style>
"""

# Inject style
if '</body>' in content:
    content = content.replace('</body>', redesign_css + '</body>')
else:
    content += redesign_css

# --- 2. HTML STRUCTURE MODIFICATIONS (HERO) ---

# Wrap the "Problem" text block
# Original roughly: <div class="mt-24px pt-20px" style="border-top:1px solid #333;"><p ...>Stop digging...</p></div>
# We want to replace the outer div classes/style with our 'hero-alert-box' or just add the class.

# Match: <div class="mt-24px pt-20px" style="border-top:1px solid #333;">
# We will replace it with: <div class="hero-alert-box">
content = content.replace(
    '<div class="mt-24px pt-20px" style="border-top:1px solid #333;">', 
    '<div class="hero-alert-box">'
)

# Style the "Money" Text
# Original: <span class="bg-100-100 ...">PUT MONEY IN YOUR POCKET.</span>
# We replace the span opening tag with our clean class.
# Use regex to be safe with the long class string.
content = re.sub(
    r'<span class="bg-100-100 [^"]*">PUT MONEY IN YOUR POCKET.</span>', 
    r'<span class="money-badge">PUT MONEY IN YOUR POCKET.</span>', 
    content
)

# Also fix the inner span if it was nested awkwardly (based on file view lines 324)
# <span class="color-FFFFFF mt-12px" ...><span class="...">PUT MONEY...</span></span>
# The script above targets the inner span. The outer span might be `display:block`. 
# Let's ensure the outer span doesn't mess up colors.
# `color-FFFFFF` on outer span might fight with `color: #555` on `.hero-alert-box p`.
# We should probably remove the `color-FFFFFF` class from that specific outer span if possible.
# <span class="color-FFFFFF mt-12px" style="display:block;  font-weight:800; ;  letter-spacing: 0.5px; line-height: 1.2;">
# Let's replace `color-FFFFFF` with `color-333` or remove it.
content = content.replace(
    '<span class="color-FFFFFF mt-12px" style="display:block;  font-weight:800; ;  letter-spacing: 0.5px; line-height: 1.2;">',
    '<span class="mt-12px" style="display:block; font-weight:800; letter-spacing: 0.5px; line-height: 1.2; color:#111;">'
)


with open(file_path, 'w', encoding='utf-8') as f:
    f.write(content)

print("Redesign Applied.")
