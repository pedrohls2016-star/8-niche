file_path = 'index.html'

with open(file_path, 'r', encoding='utf-8') as f:
    content = f.read()

animation_css = """
<style id="bg-animation">
    @keyframes bg-toggle {
        0%, 45% {
            background-color: #fff !important;
            background-image:
              linear-gradient(45deg, #ccc 25%, transparent 25%),
              linear-gradient(-45deg, #ccc 25%, transparent 25%),
              linear-gradient(45deg, transparent 75%, #ccc 75%),
              linear-gradient(-45deg, transparent 75%, #ccc 75%) !important;
            background-size: 20px 20px !important;
            background-position: 0 0, 0 10px, 10px -10px, -10px 0px !important;
            border: 1px solid #ddd !important;
        }
        50%, 95% {
            background-color: #000 !important;
            background-image: none !important;
            border: 1px solid #333 !important;
        }
        100% {
            background-color: #fff !important;
            background-image:
              linear-gradient(45deg, #ccc 25%, transparent 25%),
              linear-gradient(-45deg, #ccc 25%, transparent 25%),
              linear-gradient(45deg, transparent 75%, #ccc 75%),
              linear-gradient(-45deg, transparent 75%, #ccc 75%) !important;
            background-size: 20px 20px !important;
            background-position: 0 0, 0 10px, 10px -10px, -10px 0px !important;
             border: 1px solid #ddd !important;
        }
    }

    .dc, .v-card {
        animation: bg-toggle 20s linear infinite !important;
    }
</style>
"""

# Check if already present (to avoid duplication if my grep was wrong)
if 'id="bg-animation"' in content:
    print("Animation CSS already present. Nothing to do?")
    # Maybe update it?
    pass
else:
    if '</body>' in content:
        content = content.replace('</body>', animation_css + '</body>')
        print("Injected before </body>")
    else:
        content += animation_css
        print("Appended to end of file")

with open(file_path, 'w', encoding='utf-8') as f:
    f.write(content)
